import score
import noz_score
import plot

if __name__ == "__main__":
    sample = "/home/rothlab/rli/02_dev/08_bfg_y2h/rerun_analysis/yAD1DB1/"

    dk_sum = "dk_mcc_summary_litbm13.csv"
    noz_sum = ""
